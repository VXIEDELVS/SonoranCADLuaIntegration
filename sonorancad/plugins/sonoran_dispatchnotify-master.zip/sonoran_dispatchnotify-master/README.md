# sonoran_dispatchnotify

See [this](https://info.sonorancad.com/integration-plugins/integration-plugins/available-plugins/dispatch-notify) for documentation.